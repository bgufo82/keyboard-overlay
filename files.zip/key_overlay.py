"""
Key Overlay - a lightweight on-screen keystroke display for Windows.

Shows up to 5 squares, one per recently-pressed key. Each square fades in
the instant its key is pressed and fades out after a short hold, in sync
with the actual keyboard input. Size, opacity, colors, timings and position
are all controlled through overlay_config.json (created automatically on
first run, next to the exe / script).

Dependencies:
    pip install keyboard

Run:
    python key_overlay.py
(On Windows, global key capture generally requires an elevated/admin
terminal, or running the built exe "as administrator".)

Quit:
    Press the quit hotkey (default: ctrl+alt+q)
"""

import ctypes
import json
import os
import queue
import sys
import time
import tkinter as tk

try:
    import keyboard
except ImportError:
    print("Missing dependency 'keyboard'. Install it with:\n    pip install keyboard")
    sys.exit(1)


# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

def base_dir():
    """Directory the script/exe lives in (works for PyInstaller too)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


CONFIG_PATH = os.path.join(base_dir(), "overlay_config.json")

DEFAULT_CONFIG = {
    "num_slots": 5,             # max keys shown at once (hard cap, see note below)
    "square_size": 70,          # pixel size of each square
    "gap": 10,                  # pixel gap between squares
    "corner_radius": 12,        # rounded-corner radius
    "max_opacity": 0.85,        # 0.0 - 1.0, opacity a fully "on" square reaches
    "fade_in_ms": 120,          # fade-in duration
    "hold_ms": 550,             # time held at full opacity before fading out
    "fade_out_ms": 400,         # fade-out duration
    "bg_color": "#1e1e1e",      # square background color
    "text_color": "#ffffff",    # key label color
    "border_color": "#4da3ff",  # square border/accent color
    "font_family": "Segoe UI",
    "font_size": 20,
    "anchor": "bottom-center",  # bottom-center | bottom-left | bottom-right |
                                 # top-center | top-left | top-right | custom
    "margin": 60,                # distance from the chosen screen edge
    "position_x": None,          # only used when anchor == "custom"
    "position_y": None,          # only used when anchor == "custom"
    "click_through": True,       # let mouse clicks pass through the overlay
    "always_on_top": True,
    "quit_hotkey": "ctrl+alt+q",
    "reload_hotkey": "ctrl+alt+r",
    "ignore_keys": ["unknown"],   # key names to never display
    "fps": 60,
}

# Note on "max 5 keys at a time": num_slots hard-caps this at 5 max (you can
# lower it, but raising it above 5 is intentionally not exposed here since
# the spec is a 5-key overlay).


def load_config():
    if not os.path.exists(CONFIG_PATH):
        save_config(DEFAULT_CONFIG)
        return dict(DEFAULT_CONFIG)
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except (json.JSONDecodeError, OSError):
        cfg = {}
    merged = dict(DEFAULT_CONFIG)
    merged.update(cfg)
    merged["num_slots"] = max(1, min(5, int(merged.get("num_slots", 5))))
    return merged


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


# --------------------------------------------------------------------------
# Key name formatting
# --------------------------------------------------------------------------

KEY_LABELS = {
    "space": "Space", "enter": "Enter", "backspace": "\u232B",
    "tab": "Tab", "esc": "Esc", "escape": "Esc",
    "left": "\u2190", "right": "\u2192", "up": "\u2191", "down": "\u2193",
    "shift": "Shift", "left shift": "Shift", "right shift": "Shift",
    "ctrl": "Ctrl", "left ctrl": "Ctrl", "right ctrl": "Ctrl",
    "alt": "Alt", "alt gr": "AltGr", "left alt": "Alt", "right alt": "Alt",
    "caps lock": "Caps", "delete": "Del", "insert": "Ins",
    "page up": "PgUp", "page down": "PgDn", "home": "Home", "end": "End",
    "windows": "\u2756", "left windows": "\u2756", "right windows": "\u2756",
    "print screen": "PrSc", "num lock": "NumLk", "scroll lock": "ScrLk",
}


def format_key(name):
    name = (name or "").lower().strip()
    if name in KEY_LABELS:
        return KEY_LABELS[name]
    if name.startswith("f") and name[1:].isdigit():
        return name.upper()
    if len(name) == 1:
        return name.upper()
    return name[:6].capitalize()


# --------------------------------------------------------------------------
# Windows click-through helper
# --------------------------------------------------------------------------

def make_click_through(hwnd):
    if os.name != "nt":
        return
    GWL_EXSTYLE = -20
    WS_EX_LAYERED = 0x00080000
    WS_EX_TRANSPARENT = 0x00000020
    user32 = ctypes.windll.user32
    style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
    user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style | WS_EX_LAYERED | WS_EX_TRANSPARENT)


# --------------------------------------------------------------------------
# A single fading key square
# --------------------------------------------------------------------------

class KeySlot:
    def __init__(self, root, cfg, x, y):
        self.cfg = cfg
        size = cfg["square_size"]

        self.win = tk.Toplevel(root)
        self.win.overrideredirect(True)
        self.win.attributes("-topmost", cfg["always_on_top"])
        # A magic color made fully transparent, so only our drawn shapes show.
        self.transparent_key = "#010203"
        self.win.config(bg=self.transparent_key)
        try:
            self.win.attributes("-transparentcolor", self.transparent_key)
        except tk.TclError:
            pass  # not on Windows; overlay will just have a solid bg
        self.win.geometry(f"{size}x{size}+{x}+{y}")
        self.win.attributes("-alpha", 0.0)

        self.canvas = tk.Canvas(
            self.win, width=size, height=size,
            bg=self.transparent_key, highlightthickness=0, bd=0
        )
        self.canvas.pack(fill="both", expand=True)
        self._draw_square(size, cfg)

        self.win.update_idletasks()
        if cfg["click_through"]:
            try:
                hwnd = self.win.winfo_id()
                make_click_through(hwnd)
            except Exception:
                pass
        self.win.withdraw()

        self.active = False
        self.key = ""
        self.phase = "out"
        self.phase_start = 0.0
        self.alpha = 0.0

    def _draw_square(self, size, cfg):
        r = cfg["corner_radius"]
        pad = 2
        self.canvas.delete("all")
        self._rounded_rect(pad, pad, size - pad, size - pad, r,
                            fill=cfg["bg_color"], outline=cfg["border_color"], width=2)
        self.text_id = self.canvas.create_text(
            size / 2, size / 2, text="", fill=cfg["text_color"],
            font=(cfg["font_family"], cfg["font_size"], "bold")
        )

    def _rounded_rect(self, x1, y1, x2, y2, r, **kw):
        points = [
            x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
            x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
            x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
        ]
        self.canvas.create_polygon(points, smooth=True, **kw)

    def trigger(self, key_label):
        now = time.time()
        self.key = key_label
        self.canvas.itemconfig(self.text_id, text=key_label)
        self.active = True
        self.phase = "in"
        # start the fade-in from wherever the alpha currently is, so a key
        # that's re-pressed mid-fade doesn't visually pop
        start_alpha = self.alpha
        fraction_done = start_alpha / self.cfg["max_opacity"] if self.cfg["max_opacity"] else 0
        self.phase_start = now - fraction_done * (self.cfg["fade_in_ms"] / 1000.0)
        self.win.deiconify()

    def reposition(self, x, y, size, cfg):
        self.cfg = cfg
        self.win.geometry(f"{size}x{size}+{x}+{y}")
        self.canvas.config(width=size, height=size)
        self._draw_square(size, cfg)
        self.canvas.itemconfig(self.text_id, text=self.key)

    def update(self, now):
        if not self.active:
            return
        cfg = self.cfg
        elapsed_ms = (now - self.phase_start) * 1000.0
        max_op = cfg["max_opacity"]

        if self.phase == "in":
            t = min(1.0, elapsed_ms / max(1, cfg["fade_in_ms"]))
            self.alpha = t * max_op
            if t >= 1.0:
                self.phase = "hold"
                self.phase_start = now
        elif self.phase == "hold":
            self.alpha = max_op
            if elapsed_ms >= cfg["hold_ms"]:
                self.phase = "out"
                self.phase_start = now
        elif self.phase == "out":
            t = min(1.0, elapsed_ms / max(1, cfg["fade_out_ms"]))
            self.alpha = max_op * (1.0 - t)
            if t >= 1.0:
                self.active = False
                self.win.withdraw()
                return

        try:
            self.win.attributes("-alpha", max(0.0, min(1.0, self.alpha)))
        except tk.TclError:
            pass

    def destroy(self):
        try:
            self.win.destroy()
        except tk.TclError:
            pass


# --------------------------------------------------------------------------
# Overlay manager
# --------------------------------------------------------------------------

class OverlayApp:
    def __init__(self):
        self.cfg = load_config()
        self.event_queue = queue.Queue()

        self.root = tk.Tk()
        self.root.withdraw()  # hidden control window

        self.slots = []
        self.rr_index = 0
        self._build_slots()

        self._config_mtime = self._get_config_mtime()

        keyboard.hook(self._on_key_event, suppress=False)
        keyboard.add_hotkey(self.cfg["quit_hotkey"], self._request_quit)
        keyboard.add_hotkey(self.cfg["reload_hotkey"], self._request_reload)

        self.running = True
        self._tick()

    # -- layout -----------------------------------------------------------

    def _screen_size(self):
        return self.root.winfo_screenwidth(), self.root.winfo_screenheight()

    def _slot_positions(self):
        cfg = self.cfg
        n = cfg["num_slots"]
        size = cfg["square_size"]
        gap = cfg["gap"]
        total_w = n * size + (n - 1) * gap
        sw, sh = self._screen_size()
        margin = cfg["margin"]
        anchor = cfg["anchor"]

        if anchor == "custom" and cfg.get("position_x") is not None:
            x0 = cfg["position_x"]
            y0 = cfg["position_y"] or margin
        else:
            if "center" in anchor:
                x0 = (sw - total_w) // 2
            elif "left" in anchor:
                x0 = margin
            else:  # right
                x0 = sw - total_w - margin

            if anchor.startswith("top"):
                y0 = margin
            else:  # bottom
                y0 = sh - size - margin

        positions = []
        for i in range(n):
            positions.append((x0 + i * (size + gap), y0))
        return positions

    def _build_slots(self):
        for s in self.slots:
            s.destroy()
        self.slots = []
        positions = self._slot_positions()
        for x, y in positions:
            self.slots.append(KeySlot(self.root, self.cfg, x, y))

    def _apply_config_change(self):
        positions = self._slot_positions()
        n = self.cfg["num_slots"]
        # grow/shrink slot list to match num_slots
        while len(self.slots) < n:
            x, y = positions[len(self.slots)]
            self.slots.append(KeySlot(self.root, self.cfg, x, y))
        while len(self.slots) > n:
            self.slots.pop().destroy()
        for slot, (x, y) in zip(self.slots, positions):
            slot.reposition(x, y, self.cfg["square_size"], self.cfg)

    # -- key events (called from keyboard's hook thread) -------------------

    def _on_key_event(self, event):
        if event.event_type != "down":
            return
        name = (event.name or "").lower()
        if name in self.cfg["ignore_keys"]:
            return
        self.event_queue.put(name)

    def _request_quit(self):
        self.event_queue.put("__QUIT__")

    def _request_reload(self):
        self.event_queue.put("__RELOAD__")

    def _get_config_mtime(self):
        try:
            return os.path.getmtime(CONFIG_PATH)
        except OSError:
            return 0

    # -- main loop ----------------------------------------------------------

    def _handle_key(self, key_name):
        label = format_key(key_name)
        # if this key is already showing in a slot, refresh that slot
        for slot in self.slots:
            if slot.active and slot.key == label:
                slot.trigger(label)
                return
        # otherwise take the next slot round-robin
        slot = self.slots[self.rr_index % len(self.slots)]
        self.rr_index = (self.rr_index + 1) % len(self.slots)
        slot.trigger(label)

    def _tick(self):
        if not self.running:
            return

        # drain queued key/control events
        try:
            while True:
                item = self.event_queue.get_nowait()
                if item == "__QUIT__":
                    self.shutdown()
                    return
                elif item == "__RELOAD__":
                    self.cfg = load_config()
                    self._apply_config_change()
                else:
                    self._handle_key(item)
        except queue.Empty:
            pass

        # auto-reload if the config file was edited on disk
        mtime = self._get_config_mtime()
        if mtime != self._config_mtime:
            self._config_mtime = mtime
            self.cfg = load_config()
            self._apply_config_change()

        now = time.time()
        for slot in self.slots:
            slot.update(now)

        delay = max(10, int(1000 / max(1, self.cfg.get("fps", 60))))
        self.root.after(delay, self._tick)

    def shutdown(self):
        self.running = False
        try:
            keyboard.unhook_all()
        except Exception:
            pass
        for slot in self.slots:
            slot.destroy()
        self.root.quit()
        self.root.destroy()

    def run(self):
        self.root.mainloop()


def main():
    app = OverlayApp()
    try:
        app.run()
    except KeyboardInterrupt:
        app.shutdown()


if __name__ == "__main__":
    main()
