@echo off
REM Builds KeyOverlay.exe from key_overlay.py using PyInstaller.
REM Run this ON WINDOWS, inside this folder (double-click it, or run from cmd).

echo Installing dependencies...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo.
echo Building KeyOverlay.exe ...
python -m PyInstaller --onefile --noconsole --name KeyOverlay key_overlay.py

echo.
echo Done. Your exe is in the "dist" folder: dist\KeyOverlay.exe
echo overlay_config.json will be created next to the exe the first time you run it.
pause
